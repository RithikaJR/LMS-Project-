import React from "react";

const CourseModules = (props) =>{
    
    // console.log("about",props.location.moduleProps)
    return(
    <React.Fragment>
        <div>Module Page</div>
    </React.Fragment>
    );
 

}

export default CourseModules;