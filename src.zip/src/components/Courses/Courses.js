import React from "react";
import AvailableCourses from "./AvailableCourses";

const Courses = () => {
    return (
        <div>
            <h1 style={{textAlign: "center"}}>The Course Page</h1>
            <AvailableCourses/>

        </div>
    
    );
};

export default Courses;